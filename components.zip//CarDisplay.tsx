import { ImageWithFallback } from './figma/ImageWithFallback';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';

interface CarDisplayProps {
  id: string;
  name: string;
  model: string;
  price: string;
  specs: string[];
  imageUrl: string;
  featured?: boolean;
}

export function CarDisplay({ id, name, model, price, specs, imageUrl, featured }: CarDisplayProps) {
  return (
    <div className="relative group">
      {/* Car Platform with 3D effect */}
      <div className="relative bg-black/90 rounded-lg p-8 shadow-2xl transform transition-all duration-500 hover:scale-105">
        {/* Platform base with marble effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-black to-gray-800 rounded-lg opacity-90"></div>
        <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,0,0,0.1)_25%,rgba(255,0,0,0.1)_50%,transparent_50%,transparent_75%,rgba(255,0,0,0.1)_75%)] bg-[length:60px_60px] rounded-lg opacity-30"></div>
        
        {/* Raised platform */}
        <div className="relative bg-gradient-to-t from-black/50 to-transparent p-6 rounded-lg border border-red-500/20">
          {/* Spotlight effect */}
          <div className="absolute -top-4 left-1/2 w-32 h-32 bg-red-500/20 rounded-full blur-3xl transform -translate-x-1/2 animate-pulse"></div>
          
          {/* Car Image */}
          <div className="relative mb-6 group-hover:transform group-hover:rotate-1 transition-transform duration-500">
            <ImageWithFallback 
              src={imageUrl} 
              alt={`${name} ${model}`}
              className="w-full h-48 object-cover rounded-lg shadow-xl"
            />
            {/* Glass barrier effect */}
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/10 rounded-lg pointer-events-none"></div>
          </div>

          {/* Digital Info Panel */}
          <Card className="bg-black/80 border-red-500/30 backdrop-blur-sm">
            <div className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-red-400 tracking-wide">{name}</h3>
                  <p className="text-white/80">{model}</p>
                </div>
                {featured && (
                  <Badge className="bg-red-600 text-white border-0">Featured</Badge>
                )}
              </div>
              
              <div className="text-2xl text-white">{price}</div>
              
              <div className="space-y-2">
                {specs.map((spec, index) => (
                  <div key={index} className="flex items-center text-sm text-white/70">
                    <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                    {spec}
                  </div>
                ))}
              </div>
              
              <div className="flex gap-2 pt-2">
                <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white border-0">
                  View Details
                </Button>
                <Button size="sm" variant="outline" className="border-red-500/50 text-red-400 hover:bg-red-500/10">
                  Customize
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}