import { Card } from './ui/card';
import { Button } from './ui/button';

export function LoungeArea() {
  return (
    <section className="py-16 px-8 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl text-white mb-4">
            Comfort <span className="text-red-500">Lounge</span>
          </h2>
          <p className="text-white/70">
            Relax in our premium lounge while we prepare your personalized consultation
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Reception Desk */}
          <Card className="lg:col-span-2 bg-gradient-to-br from-black/80 to-gray-900/80 border-red-500/30 backdrop-blur-sm">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl text-white mb-2">Reception Desk</h3>
                  <p className="text-white/70">Our specialists are ready to assist you</p>
                </div>
                <div className="w-16 h-16 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                  <span className="text-white text-2xl">🏪</span>
                </div>
              </div>

              {/* Desk representation */}
              <div className="relative">
                <div className="h-24 bg-gradient-to-t from-black to-gray-800 rounded-lg shadow-2xl border border-red-500/20">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent rounded-lg"></div>
                  
                  {/* Desk items */}
                  <div className="flex items-center justify-between p-4 h-full">
                    <div className="flex items-center space-x-4">
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-white/80 text-sm">Available Now</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-5 bg-gray-700 rounded border border-gray-600"></div>
                      <div className="w-6 h-6 bg-red-600/30 rounded-full border border-red-500/50"></div>
                    </div>
                  </div>
                </div>

                {/* Chrome and glass effect */}
                <div className="absolute -bottom-2 left-4 right-4 h-1 bg-gradient-to-r from-transparent via-gray-400 to-transparent opacity-50"></div>
              </div>

              <div className="flex gap-3 mt-6">
                <Button className="bg-red-600 hover:bg-red-700 text-white">
                  Request Consultation
                </Button>
                <Button variant="outline" className="border-red-500/50 text-red-400 hover:bg-red-500/10">
                  Virtual Tour
                </Button>
              </div>
            </div>
          </Card>

          {/* Services Menu */}
          <Card className="bg-black/80 border-red-500/30 backdrop-blur-sm">
            <div className="p-6">
              <h3 className="text-xl text-red-400 mb-4">Concierge Services</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span className="text-white/80">Personal Consultation</span>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span className="text-white/80">Test Drive Scheduling</span>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span className="text-white/80">Financing Options</span>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span className="text-white/80">Trade-in Evaluation</span>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Lounge Seating Area */}
        <div className="mt-12">
          <Card className="bg-gradient-to-br from-black/60 to-gray-900/60 border-red-500/30 backdrop-blur-sm">
            <div className="p-8">
              <h3 className="text-xl text-white mb-6">Premium Seating Area</h3>
              
              {/* Seating visualization */}
              <div className="grid md:grid-cols-3 gap-6">
                {/* Leather Chairs */}
                {[1, 2, 3].map((chair) => (
                  <div key={chair} className="text-center">
                    <div className="relative mx-auto w-24 h-24 mb-4">
                      {/* Chair base */}
                      <div className="absolute bottom-0 w-full h-16 bg-gradient-to-t from-black to-gray-800 rounded-lg shadow-xl border border-red-500/20"></div>
                      {/* Chair back */}
                      <div className="absolute top-0 left-1/2 w-16 h-20 bg-gradient-to-b from-gray-800 to-black rounded-t-lg transform -translate-x-1/2 border border-red-500/20"></div>
                      {/* Red cushion accent */}
                      <div className="absolute top-2 left-1/2 w-12 h-4 bg-red-600/40 rounded transform -translate-x-1/2"></div>
                      <div className="absolute bottom-2 left-1/2 w-20 h-3 bg-red-600/40 rounded transform -translate-x-1/2"></div>
                      {/* Chrome legs */}
                      <div className="absolute -bottom-1 left-2 w-1 h-3 bg-gradient-to-b from-gray-300 to-gray-500"></div>
                      <div className="absolute -bottom-1 right-2 w-1 h-3 bg-gradient-to-b from-gray-300 to-gray-500"></div>
                    </div>
                    <p className="text-white/70 text-sm">Premium Leather</p>
                  </div>
                ))}
              </div>

              {/* Glass Coffee Table */}
              <div className="mt-8 flex justify-center">
                <div className="relative">
                  <div className="w-48 h-24 bg-gradient-to-b from-white/10 to-transparent rounded-lg border border-white/20 shadow-2xl"></div>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent rounded-lg"></div>
                  {/* Table legs */}
                  <div className="absolute -bottom-1 left-4 w-1 h-3 bg-gradient-to-b from-gray-300 to-gray-500"></div>
                  <div className="absolute -bottom-1 right-4 w-1 h-3 bg-gradient-to-b from-gray-300 to-gray-500"></div>
                  {/* Items on table */}
                  <div className="absolute top-3 left-6 w-6 h-8 bg-white/20 rounded border border-white/30"></div>
                  <div className="absolute top-4 right-8 w-4 h-4 bg-red-600/40 rounded-full"></div>
                </div>
              </div>

              <p className="text-center text-white/70 mt-4">
                Glass coffee table with luxury automotive magazines and refreshments
              </p>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}