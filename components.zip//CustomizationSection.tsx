import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useState } from 'react';

const redShades = [
  { name: 'Ferrari Red', color: '#FF2800', price: '$0' },
  { name: 'Cherry Red', color: '#DE3163', price: '+$1,500' },
  { name: 'Burgundy', color: '#800020', price: '+$2,000' },
  { name: 'Crimson', color: '#DC143C', price: '+$1,800' },
  { name: 'Ruby Red', color: '#E0115F', price: '+$2,200' },
];

const wheelOptions = [
  { name: '18" Sport Alloy', price: '$0', type: 'Standard' },
  { name: '20" Performance', price: '+$3,500', type: 'Upgrade' },
  { name: '22" Carbon Fiber', price: '+$8,000', type: 'Premium' },
];

const interiorOptions = [
  { name: 'Black Leather', price: '$0', type: 'Standard' },
  { name: 'Red & Black Combo', price: '+$2,500', type: 'Sport' },
  { name: 'Premium Red Leather', price: '+$5,000', type: 'Luxury' },
];

export function CustomizationSection() {
  const [selectedColor, setSelectedColor] = useState(redShades[0]);
  const [selectedWheels, setSelectedWheels] = useState(wheelOptions[0]);
  const [selectedInterior, setSelectedInterior] = useState(interiorOptions[0]);

  return (
    <section className="py-16 px-8 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl text-white mb-4">
            Customize Your <span className="text-red-500">Dream Car</span>
          </h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Experience our advanced customization system. Visualize different shades of red, 
            wheel designs, and interior trims in real-time.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Color Selection */}
          <Card className="bg-black/60 border-red-500/30 backdrop-blur-sm">
            <div className="p-6">
              <h3 className="text-xl text-red-400 mb-4">Paint Color</h3>
              <div className="space-y-3">
                {redShades.map((shade) => (
                  <div 
                    key={shade.name}
                    className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all ${
                      selectedColor.name === shade.name 
                        ? 'bg-red-500/20 border border-red-500/50' 
                        : 'bg-white/5 hover:bg-white/10'
                    }`}
                    onClick={() => setSelectedColor(shade)}
                  >
                    <div className="flex items-center space-x-3">
                      <div 
                        className="w-6 h-6 rounded-full border-2 border-white/20"
                        style={{ backgroundColor: shade.color }}
                      ></div>
                      <span className="text-white">{shade.name}</span>
                    </div>
                    <span className="text-red-400">{shade.price}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Wheel Selection */}
          <Card className="bg-black/60 border-red-500/30 backdrop-blur-sm">
            <div className="p-6">
              <h3 className="text-xl text-red-400 mb-4">Wheel Design</h3>
              <div className="space-y-3">
                {wheelOptions.map((wheel) => (
                  <div 
                    key={wheel.name}
                    className={`p-3 rounded-lg cursor-pointer transition-all ${
                      selectedWheels.name === wheel.name 
                        ? 'bg-red-500/20 border border-red-500/50' 
                        : 'bg-white/5 hover:bg-white/10'
                    }`}
                    onClick={() => setSelectedWheels(wheel)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white">{wheel.name}</span>
                      <Badge variant="outline" className="border-red-500/50 text-red-400">
                        {wheel.type}
                      </Badge>
                    </div>
                    <div className="text-red-400">{wheel.price}</div>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Interior Selection */}
          <Card className="bg-black/60 border-red-500/30 backdrop-blur-sm">
            <div className="p-6">
              <h3 className="text-xl text-red-400 mb-4">Interior Trim</h3>
              <div className="space-y-3">
                {interiorOptions.map((interior) => (
                  <div 
                    key={interior.name}
                    className={`p-3 rounded-lg cursor-pointer transition-all ${
                      selectedInterior.name === interior.name 
                        ? 'bg-red-500/20 border border-red-500/50' 
                        : 'bg-white/5 hover:bg-white/10'
                    }`}
                    onClick={() => setSelectedInterior(interior)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white">{interior.name}</span>
                      <Badge variant="outline" className="border-red-500/50 text-red-400">
                        {interior.type}
                      </Badge>
                    </div>
                    <div className="text-red-400">{interior.price}</div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* Configuration Summary */}
        <Card className="mt-8 bg-gradient-to-r from-black/80 to-gray-900/80 border-red-500/30">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xl text-white mb-2">Current Configuration</h4>
                <div className="space-y-1 text-white/70">
                  <p>Paint: {selectedColor.name}</p>
                  <p>Wheels: {selectedWheels.name}</p>
                  <p>Interior: {selectedInterior.name}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl text-red-400 mb-2">
                  Total: ${(85000 + 
                    parseInt(selectedColor.price.replace(/[^0-9]/g, '') || '0') +
                    parseInt(selectedWheels.price.replace(/[^0-9]/g, '') || '0') +
                    parseInt(selectedInterior.price.replace(/[^0-9]/g, '') || '0')
                  ).toLocaleString()}
                </div>
                <Button className="bg-red-600 hover:bg-red-700 text-white">
                  Save Configuration
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}