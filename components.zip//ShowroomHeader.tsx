import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function ShowroomHeader() {
  return (
    <header className="relative bg-gradient-to-r from-black via-gray-900 to-black border-b border-red-500/20">
      {/* Glass window effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent"></div>
      
      <div className="relative px-8 py-6">
        <div className="flex items-center justify-between">
          {/* Logo and Branding */}
          <div className="flex items-center space-x-4">
            <div className="text-3xl text-white tracking-wider">
              <span className="text-red-500">RED</span>
              <span className="text-white/90">LUXURY</span>
            </div>
            <Badge className="bg-red-600/20 text-red-400 border-red-500/30">
              Premium Showroom
            </Badge>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#vehicles" className="text-white/80 hover:text-red-400 transition-colors">
              Vehicles
            </a>
            <a href="#customize" className="text-white/80 hover:text-red-400 transition-colors">
              Customize
            </a>
            <a href="#financing" className="text-white/80 hover:text-red-400 transition-colors">
              Financing
            </a>
            <a href="#contact" className="text-white/80 hover:text-red-400 transition-colors">
              Contact
            </a>
          </nav>

          {/* CTA Buttons */}
          <div className="flex items-center space-x-4">
            <Button variant="outline" className="border-red-500/50 text-red-400 hover:bg-red-500/10">
              Schedule Test Drive
            </Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white">
              Get Quote
            </Button>
          </div>
        </div>
      </div>

      {/* Ambient lighting strips */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent"></div>
    </header>
  );
}