import { Card } from './ui/card';
import { Button } from './ui/button';
import { useState, useEffect } from 'react';

const promotionalContent = [
  {
    title: "Limited Edition Red Collection",
    subtitle: "Only 50 units worldwide",
    description: "Experience the ultimate in luxury with our exclusive red collection featuring premium materials and custom finishing.",
    cta: "Learn More"
  },
  {
    title: "0% Financing Available",
    subtitle: "For qualified buyers",
    description: "Take advantage of our special financing offers on select red vehicles. Terms and conditions apply.",
    cta: "Apply Now"
  },
  {
    title: "Trade-In Program",
    subtitle: "Get top dollar for your current vehicle",
    description: "Our certified appraisers will evaluate your current vehicle and offer competitive trade-in values.",
    cta: "Get Quote"
  }
];

export function DigitalScreens() {
  const [currentContent, setCurrentContent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentContent((prev) => (prev + 1) % promotionalContent.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Main Promotional Screen */}
      <Card className="col-span-full lg:col-span-2 bg-gradient-to-br from-black via-gray-900 to-black border-red-500/30 overflow-hidden">
        <div className="relative h-64 lg:h-80">
          {/* Screen bezel effect */}
          <div className="absolute inset-2 bg-black rounded-lg border border-gray-700"></div>
          
          {/* Content */}
          <div className="absolute inset-4 bg-gradient-to-br from-red-900/20 to-black rounded-lg p-6 flex flex-col justify-center">
            <div className="space-y-4">
              <div className="text-sm text-red-400 tracking-wider">
                {promotionalContent[currentContent].subtitle}
              </div>
              <h3 className="text-2xl lg:text-3xl text-white">
                {promotionalContent[currentContent].title}
              </h3>
              <p className="text-white/70 max-w-lg">
                {promotionalContent[currentContent].description}
              </p>
              <Button className="bg-red-600 hover:bg-red-700 text-white w-fit">
                {promotionalContent[currentContent].cta}
              </Button>
            </div>
          </div>

          {/* Screen reflection effect */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-30"></div>
        </div>

        {/* Progress indicators */}
        <div className="flex justify-center space-x-2 p-4">
          {promotionalContent.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentContent ? 'bg-red-500' : 'bg-white/30'
              }`}
            />
          ))}
        </div>
      </Card>

      {/* Side Information Panels */}
      <div className="space-y-6">
        {/* Performance Stats */}
        <Card className="bg-black/80 border-red-500/30 backdrop-blur-sm">
          <div className="p-4">
            <h4 className="text-red-400 mb-3">Performance Stats</h4>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-white/70">0-60 MPH</span>
                <span className="text-white">2.8s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Top Speed</span>
                <span className="text-white">205 MPH</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Horsepower</span>
                <span className="text-white">650 HP</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Torque</span>
                <span className="text-white">590 lb-ft</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Awards Display */}
        <Card className="bg-black/80 border-red-500/30 backdrop-blur-sm">
          <div className="p-4">
            <h4 className="text-red-400 mb-3">Awards & Recognition</h4>
            <div className="space-y-2">
              <div className="text-sm text-white/80">🏆 Car of the Year 2024</div>
              <div className="text-sm text-white/80">⭐ 5-Star Safety Rating</div>
              <div className="text-sm text-white/80">🎯 Best in Class Design</div>
              <div className="text-sm text-white/80">💎 Luxury Vehicle Award</div>
            </div>
          </div>
        </Card>

        {/* Live Feed */}
        <Card className="bg-black/80 border-red-500/30 backdrop-blur-sm">
          <div className="p-4">
            <h4 className="text-red-400 mb-3">Live Updates</h4>
            <div className="space-y-2 text-sm">
              <div className="text-white/70">🔴 LIVE: Virtual test drive available</div>
              <div className="text-white/70">📱 New mobile app features</div>
              <div className="text-white/70">🚗 3 vehicles reserved today</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}